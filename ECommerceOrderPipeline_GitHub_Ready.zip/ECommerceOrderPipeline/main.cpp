#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>
#include <iomanip>
#include <stdexcept>

using namespace std;

// ============================================================
// 1. SINGLETON PATTERN: shared in-memory database/config manager
// ============================================================
class DatabaseManager {
private:
    vector<string> savedOrders;

    DatabaseManager() = default;
    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

public:
    static DatabaseManager& getInstance() {
        static DatabaseManager instance;
        return instance;
    }

    void saveOrder(const string& orderId) {
        savedOrders.push_back(orderId);
        cout << "[Database] Order " << orderId << " saved.\n";
    }

    void showSavedOrders() const {
        cout << "\nSaved Orders:\n";
        if (savedOrders.empty()) {
            cout << "No orders saved.\n";
            return;
        }
        for (const auto& id : savedOrders) {
            cout << " - " << id << '\n';
        }
    }
};

// ============================================================
// 2. FACTORY METHOD PATTERN: payment interface and handlers
// ============================================================
class Payment {
public:
    virtual bool pay(double amount) = 0;
    virtual string getMethodName() const = 0;
    virtual ~Payment() = default;
};

class CreditCardPayment : public Payment {
public:
    bool pay(double amount) override {
        cout << "[Credit Card] Simulated payment of $"
             << fixed << setprecision(2) << amount << " completed.\n";
        return true;
    }
    string getMethodName() const override { return "Credit Card"; }
};

class UPIPayment : public Payment {
public:
    bool pay(double amount) override {
        cout << "[UPI] Simulated payment of $"
             << fixed << setprecision(2) << amount << " completed.\n";
        return true;
    }
    string getMethodName() const override { return "UPI"; }
};

class PayPalPayment : public Payment {
public:
    bool pay(double amount) override {
        cout << "[PayPal] Simulated payment of $"
             << fixed << setprecision(2) << amount << " completed.\n";
        return true;
    }
    string getMethodName() const override { return "PayPal"; }
};

class CryptoPayment : public Payment {
public:
    bool pay(double amount) override {
        cout << "[Crypto] Simulated payment of $"
             << fixed << setprecision(2) << amount << " completed.\n";
        return true;
    }
    string getMethodName() const override { return "Cryptocurrency"; }
};

enum class PaymentType { CREDIT_CARD = 1, UPI, PAYPAL, CRYPTO };

class PaymentFactory {
public:
    static unique_ptr<Payment> createPayment(PaymentType type) {
        switch (type) {
            case PaymentType::CREDIT_CARD:
                return make_unique<CreditCardPayment>();
            case PaymentType::UPI:
                return make_unique<UPIPayment>();
            case PaymentType::PAYPAL:
                return make_unique<PayPalPayment>();
            case PaymentType::CRYPTO:
                return make_unique<CryptoPayment>();
            default:
                throw invalid_argument("Unsupported payment method.");
        }
    }
};

// ============================================================
// 3. OBSERVER PATTERN: order status observers
// ============================================================
class OrderObserver {
public:
    virtual void update(const string& orderId, const string& status) = 0;
    virtual ~OrderObserver() = default;
};

class LogisticsListener : public OrderObserver {
public:
    void update(const string& orderId, const string& status) override {
        cout << "[Logistics] " << orderId
             << " status updated to: " << status << '\n';
    }
};

class InvoicingListener : public OrderObserver {
public:
    void update(const string& orderId, const string& status) override {
        cout << "[Invoicing] Received order event for "
             << orderId << ": " << status << '\n';
    }
};

class EmailListener : public OrderObserver {
public:
    void update(const string& orderId, const string& status) override {
        cout << "[Email] Customer notification for "
             << orderId << ": " << status << '\n';
    }
};

// ============================================================
// 4. ORDER: stores order data and notifies observers on updates
// ============================================================
class Order {
private:
    string orderId;
    double amount;
    string status;
    vector<shared_ptr<OrderObserver>> observers;

public:
    Order(const string& id, double total)
        : orderId(id), amount(total), status("Created") {
        if (amount <= 0) {
            throw invalid_argument("Order amount must be greater than zero.");
        }
    }

    const string& getOrderId() const { return orderId; }
    double getAmount() const { return amount; }
    const string& getStatus() const { return status; }

    void addObserver(const shared_ptr<OrderObserver>& observer) {
        if (observer) observers.push_back(observer);
    }

    void setStatus(const string& newStatus) {
        status = newStatus;
        cout << "\n[Order] " << orderId << " -> " << status << '\n';
        for (const auto& observer : observers) {
            observer->update(orderId, status);
        }
    }
};

// ============================================================
// 5. ORDER SERVICE: coordinates payment, persistence and events
// ============================================================
class OrderService {
public:
    bool processOrder(Order& order, Payment& payment) {
        cout << "\nProcessing " << order.getOrderId()
             << " using " << payment.getMethodName() << "...\n";

        order.setStatus("Payment Processing");

        if (!payment.pay(order.getAmount())) {
            order.setStatus("Payment Failed");
            return false;
        }

        DatabaseManager::getInstance().saveOrder(order.getOrderId());
        order.setStatus("Confirmed");
        return true;
    }
};

// ============================================================
// 6. DEMO APPLICATION
// ============================================================
int main() {
    cout << "============================================\n";
    cout << "       E-COMMERCE ORDER PIPELINE\n";
    cout << "============================================\n";

    cout << "\nSelect payment method:\n";
    cout << "1. Credit Card\n";
    cout << "2. UPI\n";
    cout << "3. PayPal\n";
    cout << "4. Cryptocurrency\n";

    int choice;
    cout << "Enter choice (1-4): ";
    if (!(cin >> choice) || choice < 1 || choice > 4) {
        cout << "Invalid payment selection. Exiting.\n";
        return 1;
    }

    double amount;
    cout << "Enter order amount (USD): ";
    if (!(cin >> amount) || amount <= 0) {
        cout << "Invalid amount. Amount must be greater than zero.\n";
        return 1;
    }

    try {
        Order order("ORD-1001", amount);

        // Register observers
        order.addObserver(make_shared<LogisticsListener>());
        order.addObserver(make_shared<InvoicingListener>());
        order.addObserver(make_shared<EmailListener>());

        // Create payment handler through Factory
        auto payment = PaymentFactory::createPayment(
            static_cast<PaymentType>(choice)
        );

        // Process order
        OrderService service;
        const bool success = service.processOrder(order, *payment);

        cout << "\nFinal Order Status: " << order.getStatus() << '\n';
        cout << "Order Processing: " << (success ? "SUCCESS" : "FAILED") << '\n';

        DatabaseManager::getInstance().showSavedOrders();

    } catch (const exception& ex) {
        cerr << "Error: " << ex.what() << '\n';
        return 1;
    }

    cout << "\nThank you for using the E-Commerce Order Pipeline!\n";
    return 0;
}
