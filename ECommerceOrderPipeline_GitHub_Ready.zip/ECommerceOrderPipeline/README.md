# E-Commerce Order Pipeline (C++)

A console-based C++ project demonstrating three object-oriented design patterns:
**Singleton**, **Factory Method**, and **Observer**. It models a simple e-commerce
order workflow with multiple simulated payment methods and real-time order-status
notifications to logistics, invoicing, and email listeners.

> **Educational demo:** Payment handlers simulate successful payments. This project
> does not connect to banks, payment gateways, cryptocurrency networks, or email/SMS
> services, and it does not process real money.

## Features

- **Singleton Pattern:** `DatabaseManager` provides one shared in-memory instance.
- **Factory Method Pattern:** `PaymentFactory` creates a handler for the selected payment method.
- **Observer Pattern:** order status changes are broadcast to registered listeners.
- Four payment handler examples:
  - Credit Card
  - UPI
  - PayPal
  - Cryptocurrency
- Order amount validation and invalid menu-input handling.
- Modern C++ resource management with `unique_ptr` and `shared_ptr`.

## Design Patterns

### 1. Singleton
`DatabaseManager::getInstance()` returns the same instance whenever it is called.
The constructor and copy operations are private/deleted to prevent additional copies.

### 2. Factory Method
`PaymentFactory::createPayment()` creates the selected implementation through
the common `Payment` interface. `OrderService` works with the interface rather
than depending on a specific payment class.

### 3. Observer
`Order` stores observer objects. Whenever `setStatus()` is called, it notifies
the registered `LogisticsListener`, `InvoicingListener`, and `EmailListener`.

## Project Structure

```text
ECommerceOrderPipeline/
├── main.cpp
├── README.md
└── .gitignore
```

## Requirements

- C++14 or later (C++17 recommended)
- GCC/MinGW, Clang, or a compatible C++ compiler
- Visual Studio, VS Code, Code::Blocks, or another C++ IDE

## Compile and Run

### Windows (MinGW)

```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o ecommerce.exe
ecommerce.exe
```

### Linux / macOS

```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o ecommerce
./ecommerce
```

## Example Run

```text
============================================
       E-COMMERCE ORDER PIPELINE
============================================

Select payment method:
1. Credit Card
2. UPI
3. PayPal
4. Cryptocurrency
Enter choice (1-4): 1
Enter order amount (USD): 250

Processing ORD-1001 using Credit Card...

[Order] ORD-1001 -> Payment Processing
[Logistics] ORD-1001 status updated to: Payment Processing
[Invoicing] Received order event for ORD-1001: Payment Processing
[Email] Customer notification for ORD-1001: Payment Processing
[Credit Card] Simulated payment of $250.00 completed.
[Database] Order ORD-1001 saved.

[Order] ORD-1001 -> Confirmed
[Logistics] ORD-1001 status updated to: Confirmed
[Invoicing] Received order event for ORD-1001: Confirmed
[Email] Customer notification for ORD-1001: Confirmed

Final Order Status: Confirmed
Order Processing: SUCCESS
```

## Simplified UML Class Diagram

```mermaid
classDiagram
    class DatabaseManager {
      -vector~string~ savedOrders
      -DatabaseManager()
      +getInstance() DatabaseManager&
      +saveOrder(string) void
    }

    class Payment {
      <<interface>>
      +pay(double) bool
      +getMethodName() string
    }
    class CreditCardPayment
    class UPIPayment
    class PayPalPayment
    class CryptoPayment
    class PaymentFactory {
      +createPayment(PaymentType) unique_ptr~Payment~
    }

    class OrderObserver {
      <<interface>>
      +update(string, string) void
    }
    class LogisticsListener
    class InvoicingListener
    class EmailListener
    class Order {
      -string orderId
      -double amount
      -string status
      +addObserver(OrderObserver) void
      +setStatus(string) void
    }
    class OrderService {
      +processOrder(Order, Payment) bool
    }

    Payment <|.. CreditCardPayment
    Payment <|.. UPIPayment
    Payment <|.. PayPalPayment
    Payment <|.. CryptoPayment
    PaymentFactory ..> Payment : creates
    OrderObserver <|.. LogisticsListener
    OrderObserver <|.. InvoicingListener
    OrderObserver <|.. EmailListener
    Order o--> OrderObserver : notifies
    OrderService ..> Payment : uses
    OrderService ..> DatabaseManager : saves through
```

## Learning Outcomes

- Understand when and how to use Singleton, Factory Method, and Observer.
- Practice interfaces through abstract classes and virtual functions.
- Apply runtime polymorphism.
- Reduce coupling between order processing and payment implementations.
- Separate order workflow responsibilities into classes.

## Possible Future Improvements

- Add persistent database storage (SQLite or another database).
- Add order line items, products, quantities, and customer details.
- Add payment failure and retry scenarios.
- Add observer removal/unsubscription.
- Add unit tests and a build system such as CMake.
- Integrate real external services only with secure credentials and proper testing.

## Author

**M Jawad Mazhar**  
BS Computer Science Student  
The University of Lahore

## License

This project is intended for educational and learning purposes. Add a license
file if you want to define reuse and distribution permissions.
